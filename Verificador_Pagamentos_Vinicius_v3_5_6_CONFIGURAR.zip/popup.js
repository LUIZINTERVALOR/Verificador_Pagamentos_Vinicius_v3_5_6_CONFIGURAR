const ids = ['bridgeUrl','bridgeToken','bridgeState','bridgePill','bridgeDot','autoDot','autoState','testBridge','importBridge','interval','timeout','saveSettings','toggleAuto','progressText','currentText','barFill','checkCount','pendingCount','errCount','lastRun','nextRun','summary','results','allFilter','copyAll','queueInfo','count','start','stop','resultCount'];
const els = Object.fromEntries(ids.map(id => [id, document.getElementById(id)]));
let filter = 'TODOS';
let bridgeDirty = false;
let lastRenderedKey = '';
let settingsDirty = false;
let settingsInitialized = false;
let filterBusy = false;

function send(message) { return new Promise(resolve => chrome.runtime.sendMessage(message, resolve)); }
function esc(v) { return String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function fmt(iso) { if (!iso) return '—'; const d = new Date(iso); return isNaN(d) ? '—' : d.toLocaleString('pt-BR', {dateStyle:'short', timeStyle:'short'}); }
function fmtExact(iso) { if (!iso) return '—'; const d = new Date(iso); return isNaN(d) ? '—' : d.toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',year:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'}); }
function humanMs(ms) { if (ms == null) return '—'; const n=Math.max(0,ms); if(n<60000)return `${Math.ceil(n/1000)} s`; const m=Math.ceil(n/60000); if(m<60)return `${m} min`; const h=Math.floor(m/60); const rest=m%60; return `${h}h${rest?` ${rest}min`:''}`; }
function copyText(value, btn) { navigator.clipboard?.writeText(String(value)).then(()=>{ const old=btn.textContent; btn.textContent='✓ COPIADO'; setTimeout(()=>btn.textContent=old,1000); }).catch(()=>{}); }
function resultClass(s) { return s==='VERIFICAR'?'green':s==='PENDENTE'?'yellow':'red'; }
function tagText(s) { return s==='VERIFICAR'?'🟢 VERIFICAR':s==='PENDENTE'?'🟡 PENDENTE':'🔴 ERRO'; }
function digits(v){ return String(v||'').replace(/\D/g,''); }

function effectiveResults(state) {
  const base = Array.isArray(state.results) ? state.results.slice() : [];
  const seen = new Set(base.map(r => digits(r.contract)).filter(Boolean));
  const queue = Array.isArray(state.queueItems) ? state.queueItems : [];
  for (const x of queue) {
    const c = digits(x.contract);
    if (!c || seen.has(c)) continue;
    base.push({ contract:c, status:'PENDENTE', name:x.name||'', dueDate:x.dueDate||'', value:x.value||'', sheet:x.sheet||'', rowNumber:Number(x.rowNumber||0), aguardando:true });
    seen.add(c);
  }
  return base;
}

function buildRenderKey(state) {
  const queue = Array.isArray(state.queueItems) ? state.queueItems : [];
  const results = effectiveResults(state);
  return JSON.stringify({
    filter,
    running: !!state.running,
    stopped: !!state.stopped,
    index: Number(state.index||0),
    total:Number(state.total||0),
    processed:Number(state.processed||0),
    bridgeConnected:!!state.bridgeConnected,
    automationEnabled:!!state.automationEnabled,
    finishedAt:state.finishedAt||null,
    nextRunAt:state.nextRunAt||null,
    queue:queue.map(x=>[x.contract,x.rowNumber,x.sheet]),
    results:results.map(r=>[r.contract,r.status,r.ponte,r.mensagem,r.nomePlanilha,r.name,r.aguardando])
  });
}

function setFilter(next, state) {
  filter = next;
  document.querySelectorAll('.statCard').forEach(card => card.classList.toggle('active', card.dataset.filter === next));
  els.allFilter.classList.toggle('active', next === 'TODOS');
  if (state) { lastRenderedKey = ''; render(state); }
}

function renderResultCard(r) {
  const c = r.contract || r.conta || '';
  const name = r.nomePlanilha || r.name || r.nome || 'Cliente sem nome';
  const due = r.dueDate || r.vencimento || '';
  const value = r.value || r.valor || '';
  const url = r.url || '';
  let detail = '';
  if (r.status === 'VERIFICAR') {
    detail = `<div class="msg success-msg">Possível pagamento encontrado. ${r.ponte==='ATUALIZADO' ? '<b>Planilha Vinícius atualizada para VERIFICAR.</b>' : '<b>Aguardando confirmação da ponte.</b>'}</div>`;
  } else if (r.status === 'PENDENTE') {
    detail = r.aguardando
      ? `<div class="msg pending-msg">Contrato recebido da Planilha Vinícius e aguardando consulta.</div>`
      : `<div class="msg pending-msg">Ficha de acordo encontrada. Permanece <b>PENDENTE</b>.</div>`;
  } else {
    detail = `<div class="msg error-msg">${esc(r.mensagem || 'Problema técnico durante a consulta.')}</div>`;
  }
  return `<div class="result ${resultClass(r.status)}">
    <div class="result-head"><div><b>Conta ${esc(c)}</b><div class="result-time">${r.consultadoEm ? esc(fmtExact(r.consultadoEm)) : 'Aguardando consulta'}</div></div><span class="tag">${tagText(r.status)}</span></div>
    <div class="result-client"><strong>Cliente:</strong> ${esc(name)}</div>
    <div class="ficha-line"><b>Vencimento:</b> ${esc(due || '—')} <span>•</span> <b>Valor:</b> ${esc(value || '—')}</div>
    ${detail}
    <div class="copy-row"><button class="copy-btn" data-copy="${esc(c)}">📋 COPIAR CONTRATO</button>${url?`<button class="copy-btn" data-open="${esc(url)}">ABRIR BOLETO</button>`:''}</div>
  </div>`;
}

function renderQueueInfo(state, queue, results) {
  const processed = Number(state.processed||0);
  const total = Number(state.total||queue.length||0);
  const pending = results.filter(r=>r.status==='PENDENTE').length;
  const verifying = results.filter(r=>r.status==='VERIFICAR').length;
  const errors = results.filter(r=>r.status==='ERRO').length;
  const stateLabel = state.running ? 'EM EXECUÇÃO' : queue.length ? 'PRONTO' : 'SEM PENDENTES';
  els.queueInfo.className = 'queue-info' + (state.running ? ' queue-running' : '') + (!state.running && queue.length ? ' queue-ready':'');
  els.queueInfo.innerHTML = `<div class="queue-count">${queue.length}</div><div class="queue-copy"><strong>${state.running ? `Verificando ${Math.min(processed+1,total)} / ${total}` : `${queue.length} contrato${queue.length===1?'':'s'} disponíveis`}</strong><small>Planilha Vinícius • 🟢 ${verifying} • 🟡 ${pending} • 🔴 ${errors}</small></div><span class="queue-state">${stateLabel}</span>`;
}

function render(state) {
  const queue = Array.isArray(state.queueItems) ? state.queueItems : [];
  const total = Number(state.total||queue.length||0);
  const processed = Number(state.processed||0);
  const results = effectiveResults(state);
  const shown = results.filter(r => filter==='TODOS' || r.status===filter);
  const key = buildRenderKey(state);
  const structureChanged = key !== lastRenderedKey;

  els.count.textContent = `${queue.length || (state.running ? total-processed : total) || 0} contrato${((queue.length || (state.running ? total-processed : total) || 0)===1)?'':'s'}`;
  els.progressText.textContent = `${processed} / ${total}`;
  els.barFill.style.width = `${total ? Math.min(100, processed/total*100) : 0}%`;
  els.currentText.textContent = state.running ? `Consultando conta ${state.current||''}` : (state.finishedAt ? 'Última rodada concluída' : (state.stopped ? 'Rodada interrompida' : 'Aguardando'));

  els.checkCount.textContent = results.filter(r=>r.status==='VERIFICAR').length;
  els.pendingCount.textContent = results.filter(r=>r.status==='PENDENTE').length;
  els.errCount.textContent = results.filter(r=>r.status==='ERRO').length;
  els.lastRun.textContent = `Última verificação: ${fmtExact(state.lastRunEnd)}`;
  updateNextRunDisplay(state);

  if (!bridgeDirty) {
    els.bridgeUrl.value = state.bridgeUrl || '';
    els.bridgeToken.value = state.bridgeToken || '';
  }
  if(!settingsDirty && !settingsInitialized){
    els.interval.value = String(state.intervalMin||30);
    els.timeout.value = String(state.timeoutMs||12000);
    settingsInitialized = true;
  }
  els.toggleAuto.innerHTML = state.automationEnabled ? '<span class="action-icon">⏸</span><span><b>PAUSAR</b><small>Interromper rotina automática</small></span>' : '<span class="action-icon">▶</span><span><b>ATIVAR</b><small>Iniciar rotina automática</small></span>';
  els.autoState.textContent = state.automationEnabled ? 'Automático ativo' : 'Automático desligado';
  els.autoDot.classList.toggle('active', !!state.automationEnabled);
  els.autoDot.classList.toggle('paused', !state.automationEnabled);
  els.bridgeState.textContent = state.bridgeConnected ? '🟢 Conectada' : (state.bridgeUrl ? '⚪ Não testada' : '⚪ Não configurada');
  els.bridgePill.textContent = state.bridgeConnected ? '🟢 Conectada' : (state.bridgeUrl ? '⚪ Não testada' : '⚪ Não configurada');
  els.bridgeDot.classList.toggle('connected', !!state.bridgeConnected);
  if (els.bridgeState.parentElement) els.bridgeState.parentElement.classList.toggle('chip-connected', !!state.bridgeConnected);
  els.start.disabled = state.running || !state.bridgeUrl;
  els.stop.disabled = !state.running;
  els.importBridge.disabled = state.running || !state.bridgeUrl;
  renderQueueInfo(state, queue, results);

  if (!structureChanged) return;
  lastRenderedKey = key;

  if (state.dailySummary) {
    const s=state.dailySummary;
    els.summary.classList.remove('hidden');
    els.summary.innerHTML=`<b>📊 Seu resumo do dia está pronto</b><div>${fmt(s.start)} → ${fmt(s.end)}</div><div>${s.total||0} contratos • 🟢 ${s.verificar||0} VERIFICAR • 🟡 ${s.pendente||0} PENDENTE • 🔴 ${s.erro||0} ERRO</div>`;
  } else els.summary.classList.add('hidden');

  if (!shown.length) {
    els.resultCount.textContent = filter === 'TODOS' ? 'Nenhum contrato aguardando ou resultado registrado.' : `0 contrato(s) em ${filter}.`;
    els.results.innerHTML='<div class="empty">Nenhum contrato neste filtro.</div>';
    return;
  }

  els.resultCount.textContent = filter==='TODOS' ? `${shown.length} item(ns) na fila/resultados.` : `${shown.length} item(ns) em ${filter}.`;
  els.results.innerHTML = shown.map(renderResultCard).join('');
  els.results.querySelectorAll('[data-copy]').forEach(b=>b.onclick=()=>copyText(b.dataset.copy,b));
  els.results.querySelectorAll('[data-open]').forEach(b=>b.onclick=()=>chrome.tabs.create({url:b.dataset.open,active:true}));
}

function updateNextRunDisplay(state) {
  if (!(state.automationEnabled && state.nextRunAt)) {
    els.nextRun.textContent='Automático: desligado';
    els.nextRun.classList.remove('countdown-live');
    return;
  }
  const at = new Date(state.nextRunAt);
  const remaining = at.getTime() - Date.now();
  const exact = fmtExact(state.nextRunAt);
  if (remaining <= 10000 && remaining > 0) {
    els.nextRun.classList.add('countdown-live');
    els.nextRun.textContent = `Próxima: ${exact} • ${Math.ceil(remaining/1000)}…`;
  } else if (remaining <= 0) {
    els.nextRun.classList.add('countdown-live');
    els.nextRun.textContent = `Próxima: ${exact} • 0`;
  } else {
    els.nextRun.classList.remove('countdown-live');
    els.nextRun.textContent = `Próxima: ${exact} • em ${humanMs(remaining)}`;
  }
}

async function refresh(){ const r=await send({type:'GET_STATE'}); if(r?.state) render(r.state); }
setInterval(async()=>{ const r=await send({type:'GET_STATE'}); if(r?.state) updateNextRunDisplay(r.state); },250);

els.bridgeUrl.addEventListener('input',()=>{ bridgeDirty=true; els.bridgeState.textContent='🟡 Não testada'; els.bridgePill.textContent='🟡 Não testada'; els.bridgeDot.classList.remove('connected'); });
els.bridgeToken.addEventListener('input',()=>{ bridgeDirty=true; });

async function saveTimingsNow(){
  const intervalMin=Number(els.interval.value);
  const timeoutMs=Number(els.timeout.value);
  if(!Number.isFinite(intervalMin) || !Number.isFinite(timeoutMs)) return;
  settingsDirty=true;
  const r=await send({type:'SAVE_TIMINGS',intervalMin,timeoutMs});
  if(!r?.ok){ settingsDirty=false; alert(r?.error||'Não foi possível salvar os tempos.'); return; }
  settingsDirty=false;
  settingsInitialized=true;
  if(r.state){
    els.interval.value=String(r.state.intervalMin||30);
    els.timeout.value=String(r.state.timeoutMs||12000);
  }
}

els.interval.addEventListener('change', saveTimingsNow);
els.timeout.addEventListener('change', saveTimingsNow);

async function saveCurrentSettings(autoOverride) {
  const current = await send({type:'GET_STATE'});
  return send({type:'SAVE_SETTINGS',bridgeUrl:els.bridgeUrl.value,bridgeToken:els.bridgeToken.value,intervalMin:Number(els.interval.value),timeoutMs:Number(els.timeout.value),automationEnabled: autoOverride === undefined ? !!current?.state?.automationEnabled : !!autoOverride});
}

els.testBridge.onclick=async()=>{
  const bridgeUrl=String(els.bridgeUrl.value||'').trim();
  const bridgeToken=String(els.bridgeToken.value||'').trim();
  if(!bridgeUrl){ alert('Cole a URL /exec da ponte da planilha.'); els.bridgeUrl.focus(); return; }
  if(!bridgeToken){ alert('Informe o TOKEN da ponte da planilha.'); els.bridgeToken.focus(); return; }
  const rSave=await saveCurrentSettings();
  if(!rSave?.ok){ alert(rSave?.error||'Não foi possível salvar a ponte.'); return; }
  bridgeDirty=false;
  const r=await send({type:'TEST_BRIDGE'});
  if(!r?.ok) alert('Erro na ponte: '+(r?.error||'desconhecido'));
  await refresh();
  if(r?.ok) alert(`Ponte conectada com sucesso.\n\n${Number(r.total||0)} PENDENTE(s) encontrados na Planilha Vinícius.`);
};

els.importBridge.onclick=async()=>{
  const bridgeUrl=String(els.bridgeUrl.value||'').trim();
  const bridgeToken=String(els.bridgeToken.value||'').trim();
  if(!bridgeUrl){ alert('Informe a URL /exec da ponte.'); els.bridgeUrl.focus(); return; }
  if(!bridgeToken){ alert('Informe o TOKEN da ponte.'); els.bridgeToken.focus(); return; }
  const rSave=await saveCurrentSettings();
  if(!rSave?.ok){ alert(rSave?.error||'Não foi possível salvar a ponte.'); return; }
  bridgeDirty=false;
  const r=await send({type:'IMPORT_BRIDGE_NOW'});
  if(!r?.ok){ alert('Erro ao atualizar a fila: '+(r?.error||'desconhecido')); return; }
  filter='TODOS';
  await refresh();
};

els.saveSettings.onclick=async()=>{
  const r=await saveCurrentSettings(true);
  if(!r?.ok) alert(r?.error||'Erro ao salvar automático.');
  bridgeDirty=false; settingsDirty=false; settingsInitialized=true; await refresh();
};

els.toggleAuto.onclick=async()=>{
  const current=await send({type:'GET_STATE'});
  const r=await saveCurrentSettings(!current?.state?.automationEnabled);
  if(!r?.ok) alert(r?.error||'Erro ao alternar automação.');
  bridgeDirty=false; settingsDirty=false; settingsInitialized=true; await refresh();
};

els.start.onclick=async()=>{
  const current=await send({type:'GET_STATE'});
  if(!current?.state?.bridgeConnected){
    const test=await send({type:'TEST_BRIDGE'});
    if(!test?.ok){ alert('A ponte precisa estar conectada antes da execução.\n\n'+(test?.error||'Erro desconhecido')); return; }
  }
  setFilter('TODOS');
  els.start.disabled=true;
  els.currentText.textContent='Iniciando a verificação…';
  const r=await send({type:'RUN_NOW'});
  if(!r?.ok) alert(r?.error||'Não foi possível iniciar a verificação.');
  await refresh();
};

els.stop.onclick=async()=>{ await send({type:'STOP_QUEUE'}); await refresh(); };
els.allFilter.onclick=async()=>{ const r=await send({type:'GET_STATE'}); if(r?.state) setFilter('TODOS',r.state); };
document.querySelectorAll('.statCard').forEach(b=>b.onclick=async()=>{ const r=await send({type:'GET_STATE'}); if(r?.state){ setFilter(b.dataset.filter,r.state); setTimeout(()=>els.results.scrollIntoView({behavior:'smooth',block:'start'}),50); } });
els.copyAll.onclick=async()=>{ const r=await send({type:'GET_STATE'}); const list=(r?.state?.results||[]).filter(x=>x.status==='VERIFICAR').map(x=>x.contract); if(!list.length){alert('Não há contratos em VERIFICAR.');return;} copyText(list.join('\n'),els.copyAll); };

refresh();
setInterval(refresh,1200);
