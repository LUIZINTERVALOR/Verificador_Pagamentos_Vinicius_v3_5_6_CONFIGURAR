(() => {
  let activeRequestId = 0;
  let activeExpectedContract = '';

  function sendResult(result) {
    chrome.runtime.sendMessage({
      type: 'TOTEM_RESULT',
      result: {
        ...result,
        requestId: activeRequestId,
        expectedContract: activeExpectedContract
      }
    });
  }

  function normalize(text) {
    return String(text || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase();
  }
  function firstMatch(text, patterns) {
    for (const re of patterns) {
      const m = text.match(re);
      if (m && m[1]) return m[1].trim();
    }
    return '';
  }
  function clickProsseguirIfPresent(raw) {
    const candidates = Array.from(document.querySelectorAll('button, input, a, [role="button"]'));
    for (const el of candidates) {
      const label = normalize(el.innerText || el.value || el.getAttribute('aria-label') || el.title || '');
      if (label === 'PROSSEGUIR' || label.includes('PROSSEGUIR')) {
        try {
          el.click();
          return true;
        } catch (_) {}
      }
    }
    return false;
  }
  function scan() {
    const raw = document.body ? document.body.innerText : '';
    const norm = normalize(raw);

    const semFicha = norm.includes('NAO HA ENTRADAS DE PARCELAMENTO PARA A CONTA') ||
      norm.includes('NAO HA ENTRADAS DE PARCELAMENTO');

    if (!semFicha && (norm.includes('PROSSEGUIR') || norm.includes('PROSSEGUIR PARA'))) {
      if (clickProsseguirIfPresent(raw)) return;
    }

    const conta = firstMatch(raw, [
      /N[ÚU]MERO\s+DA\s+CONTA\s*:?[ \t]*(\d{6,15})/i,
      /N[ÚU]MERO\s+DA\s+CONTA[\s\S]{0,30}?(\d{6,15})/i,
      /CONTA\s*:?[ \t]*(\d{6,15})/i
    ]);

    const cliente = firstMatch(raw, [
      /N[ÚU]MERO\s+DO\s+CLIENTE\s*:?[ \t]*(\d{5,15})/i,
      /N[ÚU]MERO\s+DO\s+CLIENTE[\s\S]{0,30}?(\d{5,15})/i
    ]);
    const nome = firstMatch(raw, [/NOME\s*:?[ \t]*([\s\S]*?)(?=\s+FINALIDADE)/i, /NOME\s*:?[ \t]*([^\n\r]+)/i]);
    const finalidade = firstMatch(raw, [/FINALIDADE\s*:?[ \t]*([\s\S]*?)(?=\s+DATA\s+DE\s+VENCIMENTO)/i, /FINALIDADE\s*:?[ \t]*([^\n\r]+)/i]);
    const vencimento = firstMatch(raw, [/DATA\s+DE\s+VENCIMENTO\s*:?[ \t]*(\d{2}\/\d{2}\/\d{4})/i]);
    const valor = firstMatch(raw, [/VALOR\s*:?[ \t]*(R\$\s*[\d\.\,]+)/i, /VALOR\s*:?[ \t]*([\d\.]+\,\d{2})/i]);

    if (semFicha) {
      sendResult({
        status: 'VERIFICAR', conta, cliente, nome, finalidade, vencimento, valor,
        url: location.href,
        mensagem: 'Não há entradas de parcelamento para a conta. Possível pagamento para conferência.'
      });
      return;
    }

    const fichaValida = !!conta && (
      normalize(finalidade).includes('PAGAMENTO DE ENTRADA DE PARCELAMENTO') ||
      (!!cliente && !!nome && !!vencimento && !!valor && norm.includes('FINALIDADE') && norm.includes('DATA DE VENCIMENTO'))
    );

    if (fichaValida) {
      sendResult({
        status: 'PENDENTE', conta, cliente, nome, finalidade, vencimento, valor,
        url: location.href,
        mensagem: 'Ficha de acordo de pagamento encontrada. Mantido como PENDENTE.'
      });
      return;
    }

    sendResult({
      status: 'ERRO', conta, cliente, nome, finalidade, vencimento, valor,
      url: location.href,
      texto: raw.slice(0, 3000),
      mensagem: 'A página abriu, mas a resposta não pôde ser classificada com segurança.'
    });
  }
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'SCAN_TOTEM') {
      activeRequestId = Number(msg.requestId || 0);
      activeExpectedContract = String(msg.expectedContract || '').replace(/\D/g, '');
      setTimeout(scan, 250);
    }
  });
  setTimeout(() => chrome.runtime.sendMessage({ type: 'TOTEM_READY' }), 180);
})();
